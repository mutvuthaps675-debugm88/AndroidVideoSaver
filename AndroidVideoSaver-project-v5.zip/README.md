# AndroidVideoSaver v5 — Subtitles button

New in v5:
- New dedicated **ดาวน์โหลดคำบรรยาย (SRT)** button, which opens a language picker.
- Choose Thai, Khmer, English, Chinese, Korean, Japanese, or Thai+Khmer+English.
- Uses yt-dlp `--skip-download --write-subs --write-auto-subs --sub-langs ... --convert-subs srt` to save subtitles *without* the video.
- Tries SRT conversion through FFmpeg, and also accepts available text subtitle formats (.vtt, .ass, .ttml).
- Exports files individually to `Downloads/AndroidVideoSaver` via Android MediaStore.
- Shares progress/cancel handling with video downloads; no new permissions needed.

Works only when subtitles are available for that video/language and the user has permission to download them. Automatic subtitles/translations may be inaccurate. YouTube can also deny extraction; yt-dlp updating does not guarantee access.

## Building
Unpack this ZIP in GitHub Actions and run `gradle --no-daemon assembleDebug` with Java 17 and Android SDK. This is source code, not a compiled APK. Keep `.github/workflows/build.yml` unchanged apart from switching the zip archive name to `AndroidVideoSaver-project-v5.zip`.

Library: https://github.com/yausername/youtubedl-android
yt-dlp subtitles: https://github.com/yt-dlp/yt-dlp?tab=readme-ov-file#subtitle-options
