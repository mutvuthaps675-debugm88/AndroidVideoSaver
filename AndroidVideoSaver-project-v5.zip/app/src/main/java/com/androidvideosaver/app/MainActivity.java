package com.androidvideosaver.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Environment;
import android.content.ContentValues;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.ffmpeg.FFmpeg;
import kotlin.Unit;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PROCESS_ID = "android_video_saver_active";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean engineReady = false;
    private volatile boolean busy = false;
    private volatile boolean canceled = false;
    private volatile boolean updating = false;
    private EditText urlInput;
    private Spinner quality;
    private Button downloadButton;
    private Button subtitleButton;
    private Button cancelButton;
    private Button updateButton;
    private ProgressBar progress;
    private TextView status;
    private final int navy = Color.rgb(15, 21, 38);
    private final int panel = Color.rgb(28, 37, 58);
    private final int white = Color.rgb(245, 247, 255);
    private final int secondary = Color.rgb(171, 182, 203);
    private final int violet = Color.rgb(120, 91, 250);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        drawUi();
        acceptSharedLink(getIntent());
        worker.execute(() -> {
            try {
                postStatus("กำลังเตรียมตัวดาวน์โหลด...");
                YoutubeDL.getInstance().init(getApplicationContext());
                FFmpeg.getInstance().init(getApplicationContext());
                engineReady = true;
                long last = getPreferences(MODE_PRIVATE).getLong("engine_updated_at", 0L);
                boolean shouldUpdate = last == 0L || (System.currentTimeMillis() - last) > 3L * 24 * 60 * 60 * 1000;
                if (shouldUpdate) {
                    updateEngineInWorker(true);
                } else {
                    runOnUiThread(() -> {
                        status.setText("พร้อมใช้งาน • สามารถกดอัปเดตระบบ yt-dlp ได้");
                        downloadButton.setEnabled(true);
                        subtitleButton.setEnabled(true);
                        updateButton.setEnabled(true);
                    });
                }
            } catch (Exception ex) {
                postStatus("เริ่มระบบไม่สำเร็จ: " + safeError(ex));
            }
        });
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        acceptSharedLink(intent);
    }

    private void acceptSharedLink(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String share = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (share != null) {
                for (String word : share.split("\\s+")) {
                    if (word.startsWith("https://") || word.startsWith("http://")) {
                        urlInput.setText(word);
                        break;
                    }
                }
            }
        }
    }

    private void drawUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(navy);
        // Keep the title clear of status/navigation bars on Android 15/16 edge-to-edge.
        scroll.setClipToPadding(false);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            scroll.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(22), dp(36), dp(22), dp(32));
        scroll.addView(container);

        TextView title = txt("VIDEO SAVER", 29, white, true);
        container.addView(title);
        TextView sub = txt("ดาวน์โหลดวิดีโอและเสียง • สำหรับเนื้อหาที่คุณมีสิทธิ์", 13, secondary, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8);
        container.addView(sub, sp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(18), dp(17), dp(20));
        card.setBackground(rounded(panel, 22));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(26);
        container.addView(card, cp);
        card.addView(txt("ลิงก์วิดีโอ YouTube", 16, white, true));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(white);
        urlInput.setHintTextColor(secondary);
        urlInput.setTextSize(14);
        urlInput.setHint("https://www.youtube.com/watch?v=...");
        urlInput.setPadding(dp(13), dp(12), dp(13), dp(12));
        urlInput.setBackground(rounded(navy, 12));
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(-1, dp(53));
        up.topMargin = dp(11);
        card.addView(urlInput, up);

        Button paste = makeButton("วางลิงก์จากคลิปบอร์ด", panel, white);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(44));
        pp.topMargin = dp(8);
        card.addView(paste, pp);
        paste.setOnClickListener(v -> pasteLink());

        TextView qualTitle = txt("เลือกไฟล์ที่ต้องการ", 16, white, true);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
        qp.topMargin = dp(24);
        card.addView(qualTitle, qp);
        quality = new Spinner(this);
        String[] formats = { "วิดีโอ MP4 • สูงสุด 360p", "วิดีโอ MP4 • สูงสุด 720p", "วิดีโอ MP4 • สูงสุด 1080p", "วิดีโอ MP4 • สูงสุด 4K", "เสียง MP3 • คุณภาพสูง", "เสียง M4A" };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, formats) {
            @Override public View getView(int position, View view, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(position, view, parent);
                t.setTextColor(white); t.setTextSize(15); return t;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        quality.setAdapter(adapter);
        quality.setSelection(1);
        LinearLayout.LayoutParams fs = new LinearLayout.LayoutParams(-1, dp(55));
        fs.topMargin = dp(8);
        quality.setBackground(rounded(navy, 11));
        card.addView(quality, fs);

        downloadButton = makeButton("ดาวน์โหลด", violet, white);
        downloadButton.setEnabled(false);
        LinearLayout.LayoutParams dbp = new LinearLayout.LayoutParams(-1, dp(54));
        dbp.topMargin = dp(22);
        card.addView(downloadButton, dbp);
        downloadButton.setOnClickListener(v -> startDownload());

        subtitleButton = makeButton("ดาวน์โหลดคำบรรยาย (SRT)", Color.rgb(55, 75, 113), white);
        subtitleButton.setEnabled(false);
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(-1, dp(50));
        sbp.topMargin = dp(8);
        card.addView(subtitleButton, sbp);
        subtitleButton.setOnClickListener(v -> selectSubtitleLanguage());

        cancelButton = makeButton("ยกเลิก", Color.rgb(70, 79, 100), white);
        cancelButton.setEnabled(false);
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(-1, dp(48));
        cbp.topMargin = dp(8);
        card.addView(cancelButton, cbp);
        cancelButton.setOnClickListener(v -> cancelDownload());

        updateButton = makeButton("อัปเดตระบบดาวน์โหลด yt-dlp", Color.rgb(43, 56, 78), white);
        updateButton.setEnabled(false);
        LinearLayout.LayoutParams ubp = new LinearLayout.LayoutParams(-1, dp(48));
        ubp.topMargin = dp(10);
        card.addView(updateButton, ubp);
        updateButton.setOnClickListener(v -> updateEngine());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(violet));
        LinearLayout.LayoutParams prp = new LinearLayout.LayoutParams(-1, dp(10));
        prp.topMargin = dp(22);
        card.addView(progress, prp);

        status = txt("กำลังเตรียมระบบ...", 14, secondary, false);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(12);
        card.addView(status, stp);

        TextView note = txt("ไฟล์วิดีโอ เสียง และคำบรรยายจะอยู่ใน Downloads/AndroidVideoSaver\nคำบรรยายจะดาวน์โหลดเฉพาะภาษาที่มีให้ใช้งาน\nเปิดแอประหว่างดาวน์โหลดไว้ก่อน (เวอร์ชันทดลอง)", 13, secondary, false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(24);
        container.addView(note, np);
        setContentView(scroll);
    }

    private void pasteLink() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) return;
        ClipData data = clipboard.getPrimaryClip();
        if (data != null && data.getItemCount() > 0) {
            CharSequence pasted = data.getItemAt(0).coerceToText(this);
            if (pasted != null) urlInput.setText(pasted.toString().trim());
        }
    }

    private boolean validYoutubeLink(String raw) {
        try {
            Uri u = Uri.parse(raw.trim());
            String s = u.getScheme();
            String h = u.getHost();
            if (s == null || h == null || !(s.equals("https") || s.equals("http"))) return false;
            h = h.toLowerCase(Locale.ROOT);
            return h.equals("youtu.be") || h.equals("youtube.com") || h.endsWith(".youtube.com");
        } catch (Exception ignored) { return false; }
    }

    private void updateEngine() {
        if (!engineReady || busy || updating) return;
        worker.execute(() -> updateEngineInWorker(false));
    }

    private void updateEngineInWorker(boolean automatic) {
        updating = true;
        runOnUiThread(() -> {
            downloadButton.setEnabled(false);
            subtitleButton.setEnabled(false);
            updateButton.setEnabled(false);
            status.setText("กำลังตรวจและอัปเดต yt-dlp จาก GitHub... กรุณารอสักครู่");
        });
        String message;
        try {
            YoutubeDL.getInstance().updateYoutubeDL(getApplicationContext(), YoutubeDL.UpdateChannel.NIGHTLY);
            getPreferences(MODE_PRIVATE).edit()
                    .putLong("engine_updated_at", System.currentTimeMillis()).apply();
            message = "อัปเดต yt-dlp สำเร็จ • ลองดาวน์โหลดอีกครั้ง";
        } catch (Exception ex) {
            message = "ยังอัปเดต yt-dlp ไม่สำเร็จ: " + safeError(ex)
                    + "\nตรวจอินเทอร์เน็ต แล้วกดปุ่มอัปเดตอีกครั้ง";
        } finally {
            updating = false;
        }
        final String result = message;
        runOnUiThread(() -> {
            status.setText(result);
            downloadButton.setEnabled(engineReady && !busy);
            subtitleButton.setEnabled(engineReady && !busy);
            updateButton.setEnabled(engineReady && !busy);
        });
    }

    private void startDownload() {
        if (busy || updating || !engineReady) return;
        String url = urlInput.getText().toString().trim();
        if (!validYoutubeLink(url)) {
            urlInput.setError("กรุณาใส่ลิงก์ YouTube ที่ถูกต้อง");
            return;
        }
        final int selected = quality.getSelectedItemPosition();
        busy = true;
        canceled = false;
        downloadButton.setEnabled(false);
        subtitleButton.setEnabled(false);
        updateButton.setEnabled(false);
        cancelButton.setEnabled(true);
        progress.setProgress(0);
        postStatus("กำลังดาวน์โหลด...");
        worker.execute(() -> runDownload(url, selected));
    }

    private void runDownload(String url, int choice) {
        File dir = null;
        try {
            File parent = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (parent == null) parent = getFilesDir();
            dir = new File(parent, "job_" + System.currentTimeMillis());
            if (!dir.mkdirs()) throw new Exception("ไม่สามารถสร้างโฟลเดอร์ชั่วคราว");
            YoutubeDLRequest req = new YoutubeDLRequest(url);
            req.addOption("--no-playlist");
            req.addOption("--no-mtime");
            // YouTube may require an external JavaScript challenge solver.
            // QuickJS is bundled by youtubedl-android 0.18.1; EJS scripts are fetched on demand.
            req.addOption("--js-runtimes", "quickjs");
            req.addOption("--remote-components", "ejs:github");
            req.addOption("-o", new File(dir, "%(title).80s_%(id)s.%(ext)s").getAbsolutePath());
            if (choice <= 3) {
                int height = choice == 0 ? 360 : choice == 1 ? 720 : choice == 2 ? 1080 : 2160;
                req.addOption("-f", "bv[height<=" + height + "][ext=mp4]+ba[ext=m4a]/bv[height<=" + height + "]+ba/b[height<=" + height + "]");
                req.addOption("--merge-output-format", "mp4");
            } else {
                req.addOption("-f", "bestaudio/best");
                req.addOption("-x");
                req.addOption("--audio-format", choice == 4 ? "mp3" : "m4a");
                if (choice == 4) req.addOption("--audio-quality", "0");
            }
            YoutubeDL.getInstance().execute(req, PROCESS_ID, (p, eta, line) -> {
                runOnUiThread(() -> {
                    progress.setProgress(Math.max(0, Math.min(100, Math.round(p))));
                    status.setText(String.format(Locale.getDefault(), "ดาวน์โหลด %.0f%% • รอประมาณ %d วินาที", p, Math.max(0, eta)));
                });
                return Unit.INSTANCE;
            });
            if (canceled) { postStatus("ยกเลิกการดาวน์โหลดแล้ว"); return; }
            postStatus("กำลังบันทึกลง Downloads...");
            File output = findOutput(dir);
            if (output == null) throw new Exception("ไม่พบไฟล์ที่ดาวน์โหลดเสร็จ");
            Uri target = saveToDownloads(output);
            if (target == null) throw new Exception("ไม่สามารถบันทึกไฟล์ลง Downloads");
            runOnUiThread(() -> {
                progress.setProgress(100);
                status.setText("สำเร็จ! อยู่ที่ Downloads/AndroidVideoSaver/" + output.getName());
            });
        } catch (Exception ex) {
            postStatus(canceled ? "ยกเลิกการดาวน์โหลดแล้ว" : "เกิดข้อผิดพลาด: " + safeError(ex));
        } finally {
            if (dir != null) deleteDir(dir);
            busy = false;
            runOnUiThread(() -> {
                downloadButton.setEnabled(engineReady && !updating);
                subtitleButton.setEnabled(engineReady && !updating);
                updateButton.setEnabled(engineReady && !updating);
                cancelButton.setEnabled(false);
            });
        }
    }

    /** Download subtitles separately without downloading the video. */
    private void selectSubtitleLanguage() {
        if (!engineReady || busy || updating) return;
        String[] labels = {
                "ภาษาไทย (th)", "ภาษาเขมร (km)", "ภาษาอังกฤษ (en)",
                "ภาษาจีน (zh)", "ภาษาเกาหลี (ko)", "ภาษาญี่ปุ่น (ja)",
                "ไทย + เขมร + อังกฤษ"
        };
        String[] patterns = {
                "th.*", "km.*", "en.*", "zh.*", "ko.*", "ja.*",
                "th.*,km.*,en.*"
        };
        new AlertDialog.Builder(this)
                .setTitle("เลือกภาษาคำบรรยาย")
                .setMessage("รองรับซับที่ผู้สร้างเพิ่มไว้ และซับอัตโนมัติเมื่อมีให้ดาวน์โหลด")
                .setItems(labels, (dialog, position) -> startSubtitleDownload(patterns[position], labels[position]))
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void startSubtitleDownload(String languages, String label) {
        if (!engineReady || busy || updating) return;
        String url = urlInput.getText().toString().trim();
        if (!validYoutubeLink(url)) {
            urlInput.setError("กรุณาใส่ลิงก์ YouTube ที่ถูกต้อง");
            return;
        }
        busy = true;
        canceled = false;
        downloadButton.setEnabled(false);
        subtitleButton.setEnabled(false);
        updateButton.setEnabled(false);
        cancelButton.setEnabled(true);
        progress.setProgress(0);
        postStatus("กำลังค้นหาคำบรรยาย " + label + "...");
        worker.execute(() -> runSubtitleDownload(url, languages, label));
    }

    private void runSubtitleDownload(String url, String languages, String label) {
        File dir = null;
        try {
            File parent = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (parent == null) parent = getFilesDir();
            dir = new File(parent, "subtitle_job_" + System.currentTimeMillis());
            if (!dir.mkdirs()) throw new Exception("ไม่สามารถสร้างโฟลเดอร์ชั่วคราว");
            YoutubeDLRequest req = new YoutubeDLRequest(url);
            req.addOption("--no-playlist");
            req.addOption("--skip-download");
            req.addOption("--write-subs");
            req.addOption("--write-auto-subs");
            req.addOption("--sub-langs", languages);
            req.addOption("--sub-format", "srt/vtt/best");
            req.addOption("--convert-subs", "srt");
            req.addOption("--js-runtimes", "quickjs");
            req.addOption("--remote-components", "ejs:github");
            req.addOption("-o", new File(dir, "%(title).80s_%(id)s.%(ext)s").getAbsolutePath());
            YoutubeDL.getInstance().execute(req, PROCESS_ID, (p, eta, line) -> {
                runOnUiThread(() -> progress.setProgress(Math.max(0, Math.min(100, Math.round(p)))));
                return Unit.INSTANCE;
            });
            if (canceled) { postStatus("ยกเลิกการดาวน์โหลดคำบรรยายแล้ว"); return; }
            File[] subtitles = dir.listFiles(file -> {
                if (!file.isFile() || file.length() <= 0) return false;
                String name = file.getName().toLowerCase(Locale.ROOT);
                return name.endsWith(".srt") || name.endsWith(".vtt")
                        || name.endsWith(".ass") || name.endsWith(".ttml");
            });
            if (subtitles == null || subtitles.length == 0) {
                postStatus("ไม่พบคำบรรยาย " + label + " สำหรับวิดีโอนี้\nลองเลือกภาษาอื่นหรือวิดีโอที่มีซับ");
                return;
            }
            Arrays.sort(subtitles, Comparator.comparing(File::getName));
            int saved = 0;
            for (File file : subtitles) {
                if (canceled) { postStatus("ยกเลิกการดาวน์โหลดคำบรรยายแล้ว"); return; }
                saveToDownloads(file);
                saved++;
            }
            final int total = saved;
            runOnUiThread(() -> {
                progress.setProgress(100);
                status.setText("บันทึกคำบรรยายสำเร็จ " + total
                        + " ไฟล์\nDownloads/AndroidVideoSaver (SRT หรือไฟล์ต้นฉบับ)");
            });
        } catch (Exception ex) {
            postStatus(canceled ? "ยกเลิกการดาวน์โหลดคำบรรยายแล้ว"
                    : "ดาวน์โหลดคำบรรยายไม่สำเร็จ: " + safeError(ex));
        } finally {
            if (dir != null) deleteDir(dir);
            busy = false;
            runOnUiThread(() -> {
                downloadButton.setEnabled(engineReady && !updating);
                subtitleButton.setEnabled(engineReady && !updating);
                updateButton.setEnabled(engineReady && !updating);
                cancelButton.setEnabled(false);
            });
        }
    }

    private File findOutput(File dir) {
        File[] files = dir.listFiles(file -> {
            if (!file.isFile() || file.length() <= 0) return false;
            String name = file.getName().toLowerCase(Locale.ROOT);
            return name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") || name.endsWith(".m4a") || name.endsWith(".mp3");
        });
        if (files == null || files.length == 0) return null;
        Arrays.sort(files, (a, b) -> Long.compare(b.length(), a.length()));
        return files[0];
    }

    private Uri saveToDownloads(File file) throws Exception {
        ContentResolver resolver = getContentResolver();
        String mime = file.getName().endsWith(".srt") ? "application/x-subrip"
                : file.getName().endsWith(".vtt") ? "text/vtt"
                : file.getName().endsWith(".ass") ? "text/plain"
                : file.getName().endsWith(".ttml") ? "application/ttml+xml"
                : file.getName().endsWith(".mp3") ? "audio/mpeg"
                : file.getName().endsWith(".m4a") ? "audio/mp4"
                : file.getName().endsWith(".webm") ? "video/webm"
                : file.getName().endsWith(".mkv") ? "video/x-matroska" : "video/mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, file.getName());
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AndroidVideoSaver");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("ไม่สามารถสร้างไฟล์ปลายทาง");
        try (InputStream in = new FileInputStream(file); OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new Exception("ไม่สามารถเปิดไฟล์ปลายทาง");
            byte[] buffer = new byte[128 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
            return uri;
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }
    }

    private void cancelDownload() {
        if (!busy) return;
        canceled = true;
        cancelButton.setEnabled(false);
        postStatus("กำลังยกเลิก...");
        new Thread(() -> {
            try { YoutubeDL.getInstance().destroyProcessById(PROCESS_ID); }
            catch (Exception ignored) { }
        }, "cancel-download").start();
    }

    private static void deleteDir(File f) {
        if (f == null) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteDir(child);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private void postStatus(String text) { runOnUiThread(() -> status.setText(text)); }
    private String safeError(Exception e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }
    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }
    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }
    private Button makeButton(String label, int background, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackground(rounded(background, 12));
        return b;
    }
    @Override protected void onDestroy() {
        if (busy) cancelDownload();
        worker.shutdown();
        super.onDestroy();
    }
}
