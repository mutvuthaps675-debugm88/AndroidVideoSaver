# AndroidVideoSaver (Android)

Starter Android app for downloading video/audio **you own or have authorization to download**. YouTube's terms may restrict downloading outside permitted methods. This project does not bypass DRM or authentication.

Features:
- Paste/share an authorized YouTube URL
- Select up to 360p/720p/1080p/4K, or MP3/M4A
- Download progress and cancellation
- Use Android MediaStore to save results to `Downloads/AndroidVideoSaver`
- Thai UI

Tech stack: Android Java, Android Gradle Plugin 8.7.3, Gradle 8.9, API min 29, 64-bit ARM, yt-dlp Android 0.18.1 and FFmpeg.

## Build on GitHub Actions using just a ZIP and one workflow

1. Put `AndroidVideoSaver-project.zip` in the **root** of your GitHub repository.
2. Create `.github/workflows/build.yml` with the separate workflow file.
3. Open GitHub Actions > Build APK > latest run > Artifacts > `AndroidVideoSaver-debug-apk`.
4. Unzip the artifact to install the APK. GitHub Actions has to succeed first.

## Local Android Studio

Extract `AndroidVideoSaver-project.zip` and import the extracted root folder as a Gradle project.

## Known limitations

- This starter build has not been run on a physical Android device here.
- YouTube changes can break extractors, change format availability, or require user authentication.
- Keep the app foregrounded while downloading; foreground services and persistent queues are not yet implemented.
- Best available quality means at or below the selected maximum; high resolutions require formats supplied by the site.
- This is a personal testing build and a debug APK. It is not signed for Play Store distribution.

## Open source

This project uses youtubedl-android (GPL-3.0) and yt-dlp, plus FFmpeg. If distributing the compiled app, satisfy the licenses of its dependencies (including providing corresponding source code where required).


### Patch v3 (2026-10-19)
Fix FFmpeg import: com.yausername.ffmpeg.FFmpeg. v1 and v2 used incorrect package imports.
