# AndroidVideoSaver v6 - Stable fallback with subtitles

This revision is based on the Android source of v5, but removes the new background updater API and update button to isolate compilation failures. It keeps the original download flow that compiled successfully in v3 and adds a selectable subtitle downloader. This is a fallback until the exact v5 compiler diagnostic can be reviewed.

- Video/audio download (with QuickJS/EJS yt-dlp request options)
- Subtitle language selector: Thai, Khmer, English, Chinese, Korean, Japanese or a group
- Requests captions separately with `--skip-download --write-subs --write-auto-subs --convert-subs srt`
- Exports available subtitles through Android MediaStore into `Downloads/AndroidVideoSaver`.

Requires captions/permission and a working YouTube extraction backend. HTTP 403 may still occur; this code does not bypass access controls. Some subtitles may remain in their original format if conversion is unavailable.

Validation: ZIP integrity tested; Java source checked by `javac` with local API stubs. The real Android Gradle build was not executed in this workspace. Use GitHub Actions and send the `error:` lines if it fails.
